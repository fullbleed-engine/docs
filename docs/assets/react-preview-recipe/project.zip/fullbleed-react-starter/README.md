# React PDF preview lifecycle recipe

A focused React form connected to the Fullbleed component invoice and preview
hook. All example data is fictional. MIT licensed.

## Run

Use Node.js 22.13+ on the 22.x line, or Node.js 23.5+ (including 24.x).
Run `npm ci`, then `npm run dev`. Open the localhost URL from Vite.

The customer name and paid status change the PDF. Automatic rendering waits
for a short pause in typing. Turn it off to use Generate PDF explicitly.
An empty customer clears the old output. Cancel stops pending work. Closing
the editor releases its resources; reopening starts with the sample values.

App.tsx is the focused form. The document is composed in
src/documents/Invoice.tsx using Fullbleed's JSX runtime. Print rules are attached
from invoiceStyles.ts; src/style.css styles the surrounding React application.
The unchanged invoice.html/report.html sources from the larger starter are
included for reference but are not selected by this form.

`npm run build` checks TypeScript, copies the package runtime, and builds dist/.
Deploy that complete folder to a static HTTPS host. No PDF server is required.
Keep the supplied lockfile: it pins fullbleed 0.8.2 (engine 2.5.37), React 19.3.0,
TypeScript 7.0.2, Vite 8.3.2 and its portable bundler runtime.

Guide and verification:
https://docs.fullbleed.dev/guides/react-pdf-preview-lifecycle/

Full starter:
https://docs.fullbleed.dev/guides/react-pdf/
