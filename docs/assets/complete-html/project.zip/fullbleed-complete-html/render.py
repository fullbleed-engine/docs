from importlib.resources import files
from pathlib import Path
import fullbleed

ROOT = Path(__file__).resolve().parent
assert fullbleed.build_features().get("embedded_stylesheets", False)
font = files("fullbleed_assets").joinpath("fonts/Inter-Variable.ttf")
engine = fullbleed.PdfEngine(
    font_files=[str(font)], document_title="Northstar Studio / Invoice",
    document_lang="en", document_timestamp="2026-10-16T00:00:00Z",
)
html = (ROOT / "invoice.html").read_text(encoding="utf-8")
(ROOT / "invoice.pdf").write_bytes(engine.render_pdf(html, ""))
for number, preview in enumerate(engine.render_image_pages(html, "", dpi=96), 1):
    (ROOT / f"invoice-page-{number}.png").write_bytes(bytes(preview))
