Fullbleed complete HTML example

This fictional invoice keeps its CSS in invoice.html. Its colors, typography,
column layout, progress indicators, and page settings use the native engine.

1. python -m pip install -r requirements.txt
2. python render.py
3. Open invoice.pdf or invoice-page-1.png.

Edit the HTML and its style element together. Inter is supplied by Fullbleed;
no remote stylesheet, browser, or system font is used by this example.
The fixed timestamp makes this example reproducible; select your own document
metadata for production. The source is MIT licensed.
