# Fullbleed 2.5.6 / 2.5.7 font-subset evidence

The `before` and `after` folders contain nine synthetic fixtures rendered from
installed public packages on one Windows host. Each includes source HTML/CSS,
PDFs, independent PDFium previews, native Fullbleed previews, and a JSON report.
`release.json` identifies the tested source and publication checks.

The separate `goldens-before` and `goldens-after` folders retain the three
existing example documents. Their report compares file sizes, extracted text,
independent pixels, and native preview hashes. These are retained observations,
not a general renderer, standards-conformance, or printer-compatibility claim.

`MANIFEST.json` records the SHA-256 and length of every other archive member.
Raw reports retain paths from the machines that produced them. Those paths are
provenance, not paths that must exist on your computer.

## Reproduce the nine-fixture comparison

Clone the full release source; the three Python files in this archive are
reference copies and need the repository's fixtures and licensed font assets.

```sh
git clone --branch v2.5.7 https://github.com/fullbleed-engine/fullbleed-official.git
cd fullbleed-official
python -m venv .venv
```

Activate that environment with `.venv\Scripts\Activate.ps1` in PowerShell or
`source .venv/bin/activate` in a Unix shell. Then run:

```sh
python -m pip install fullbleed==2.5.6 pypdf==6.19.0 pypdfium2==5.14.0 fonttools==4.65.0 pillow==12.3.0
python -I tools/smoke_font_subsets.py --out target/font-baseline --allow-legacy-metadata
python -m pip install --upgrade fullbleed==2.5.7
python -I tools/smoke_font_subsets.py --out target/font-candidate --baseline target/font-baseline
```

Use new output directories on each run. The script fixes the document timestamp,
checks repeated PDF bytes, checks glyph programs and metrics independently, and
compares both text readers and preview hashes. Running the normal check against
2.5.6 without `--allow-legacy-metadata` rejects its old font metadata.

Consult `source/2.5.7-runbook.md` for the broader release checks. The release
includes no new runtime dependency; the reader libraries above are test tools.
Font notices and the repository's license records are included in this archive.
