"""Render the linked report with the pinned, installed Fullbleed wheel."""
from hashlib import sha256
from importlib.metadata import version
from importlib.resources import files
import json
from pathlib import Path

import fullbleed

HERE = Path(__file__).resolve().parent
PIN = '2.6.0a14'


def main():
    installed = version('fullbleed')
    if installed != PIN:
        raise RuntimeError(f'This example is qualified with fullbleed=={PIN}; found {installed}.')
    html = (HERE / 'report.html').read_text(encoding='utf-8')
    css = (HERE / 'report.css').read_text(encoding='utf-8')
    font = files('fullbleed_assets').joinpath('fonts/Inter-Variable.ttf')
    engine = fullbleed.PdfEngine(
        font_files=[str(font)],
        document_title='Every page, within reach — a linked report',
        document_lang='en-US',
        document_timestamp='2026-10-23T00:00:00Z',
    )
    out = HERE / 'output'
    out.mkdir(exist_ok=True)
    pdf = bytes(engine.render_pdf(html, css))
    (out / 'linked-report.pdf').write_bytes(pdf)
    images = engine.render_image_pages(html, css, dpi=144)
    for number, image in enumerate(images, start=1):
        (out / f'page-{number}.png').write_bytes(bytes(image))
    report = dict(version=installed, pages=len(images), pdf_sha256=sha256(pdf).hexdigest(),
                  pdf_bytes=len(pdf), source_sha256={
                      name: sha256((HERE / name).read_bytes()).hexdigest()
                      for name in ('report.html', 'report.css', 'render.py')})
    (out / 'render.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
