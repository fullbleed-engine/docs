# A linked report with Fullbleed

This two-page example uses ordinary HTML anchors for PDF section jumps, a web
link, and an email link. It uses fictional project data and the Inter font
bundled with Fullbleed; the renderer does not fetch remote assets.

Use Python 3.10 or later in a virtual environment:

```sh
python -m pip install -r requirements.txt
python render.py
```

Open `output/linked-report.pdf` in a PDF reader. Select **Project notes** on
page 1 to jump to page 2, then **Back to overview** to return. The second
internal link targets the lower section on page 2. The documentation link
opens a web page; the illustrative email link uses `hello@example.com`.

Edit `report.html` for content and destinations, and `report.css` for styles.
Use unique `id` values and point internal links to them with `href="#id"`.
Native PDF navigation requires this pinned prerelease: stable 2.5.34 predates
the feature. PDF-reader security settings can affect external link activation.

The two PNG previews show the layout; images do not carry interactive links.
The downloadable kit also keeps the checked PDF and previews under `baseline/`.
The example checks do not establish PDF/UA or assistive-technology conformance.

MIT licensed. See `LICENSE`.
